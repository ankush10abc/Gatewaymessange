import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:app_links/app_links.dart';

import 'app/app.dart';
import 'core/services/notification_handler.dart';
import 'core/services/firebase_realtime_service.dart';
import 'core/services/deep_link_service.dart';

// Top-level background message handler
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(options: const FirebaseOptions(apiKey: 'AIzaSyA2qeQyT5BTYvFOt3ruL-ufeK1dkL_NGvQ', appId: '1:335214113602:android:d4ef30b1fa628b93228edb', messagingSenderId: '335214113602', projectId: 'reportgateway-28186'));
  await NotificationHandler.backgroundMessageHandler(message);
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    // Initialize Firebase
    await Firebase.initializeApp(options:
     FirebaseOptions(
      apiKey: 'AIzaSyA2qeQyT5BTYvFOt3ruL-ufeK1dkL_NGvQ',
      appId: '1:335214113602:android:d4ef30b1fa628b93228edb',
      messagingSenderId: '335214113602',
      projectId: 'reportgateway-28186'
    )
    );
    
    // Use emulator for development (comment out for production)
    // FirebaseFirestore.instance.useFirestoreEmulator('localhost', 8080);
    
    // Configure Firestore settings after initialization
    FirebaseFirestore.instance.settings =  Settings(
      persistenceEnabled: false,
      cacheSizeBytes: 1048576, // 1MB
    );
    
    // Set background message handler
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
    
    // Initialize notifications
    await NotificationHandler.initialize();
    
    // Initialize deep linking
    // _initDeepLinks();
  } catch (e) {
    debugPrint('Firebase initialization error: $e');
  }

  runApp(
    ProviderScope(
      child: const MyApp(),
    ),
  );
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GatewayMessengerApp();
    //
  }
}

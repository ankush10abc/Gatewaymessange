import 'package:flutter/material.dart';

class WarningSlider extends StatefulWidget {
  const WarningSlider({super.key});

  @override
  _WarningSliderState createState() => _WarningSliderState();
}

class _WarningSliderState extends State<WarningSlider>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<Offset> _slideAnimation;
  bool _isEnglish = true;
  double _textWidth = 0;
  final GlobalKey _textKey = GlobalKey();

  final String englishText =
      "All messages sent on the phone are for parents only. Please do not give mobile phones to children. The school does not assign any work to students via phone.";
  final String hindiText =
      'फोन पर भेजे जाने वाले सभी संदेश केवल अभिभावकों के लिए हैं। कृपया बच्चों को मोबाइल फोन न दें। स्कूल द्वारा फोन पर बच्चों को कोई काम नहीं दिया जाता है।';

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(seconds: 12),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(1.0, 0.0),
      end: const Offset(-0.4, 0.0),
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.linear,
    ));

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startAnimation();
    });
  }

  void _startAnimation() {
    _animationController.forward().then((_) {
      if (mounted) {
        setState(() {
          _isEnglish = !_isEnglish;
        });
        _animationController.reset();
        _startAnimation();
      }
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      color: Colors.orange[100],
      child: ClipRect(
        child: OverflowBox(
          maxWidth: double.infinity,
          child: SlideTransition(
            position: _slideAnimation,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.warning_amber_rounded,
                    color: Colors.orange[800],
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _isEnglish ? englishText : hindiText,
                    key: _textKey,
                    style: TextStyle(
                      color: Colors.orange[800],
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.visible,
                  ),
                  const SizedBox(width: 50),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

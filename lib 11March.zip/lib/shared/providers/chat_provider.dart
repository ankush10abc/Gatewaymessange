import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';
import '../../core/models/chat_model.dart';
import '../../core/models/message_model.dart';
import '../../core/services/firebase_service.dart';
import '../../core/services/api_service_simple.dart';
import '../../core/storage/storage_service.dart';

class ChatState {
  final List<Chat> chats;
  final bool isLoading;
  final String? error;

  ChatState({
    this.chats = const [],
    this.isLoading = false,
    this.error,
  });

  ChatState copyWith({
    List<Chat>? chats,
    bool? isLoading,
    String? error,
  }) {
    return ChatState(
      chats: chats ?? this.chats,
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }
}

class ChatNotifier extends StateNotifier<ChatState> {
  late final ApiService _apiService;
  final StorageService _storage = StorageService();

  ChatNotifier() : super(ChatState()) {
    final dio = Dio();
    _apiService = ApiService(dio);
  }

  Future<void> loadChatList() async {
    state = state.copyWith(isLoading: true);
    
    try {
      // Set auth token
      final token = await _storage.getToken();
      if (token != null) {
        _apiService.setAuthToken(token);
      }
      
      debugPrint('Loading chat list...');
      final response = await _apiService.getChatList();
      debugPrint('Chat list response: $response');
      debugPrint('Response type: ${response.runtimeType}');
      debugPrint('Response length: ${response.length}');
      
      final chats = <Chat>[];
      
      // Add a test chat to verify UI is working
      // chats.add(Chat(
      //   id: '14',
      //   type: 'group',
      //   participants: [],
      //   createdAt: DateTime.now(),
      //   updatedAt: DateTime.now(),
      //   unreadCount: {},
      //   isPinned: false,
      //   groupName: 'Fees Group',
      // ));
      
      for (final item in response) {
        debugPrint('Processing chat item: $item');
        final itemMap = item as Map<String, dynamic>;
        if (itemMap['type'] == 'group') {
          // Handle group chat
          chats.add(Chat(
            id: itemMap['id'].toString(),
            type: 'group',
            participants: [],
            createdAt: DateTime.tryParse(itemMap['updated_at'] ?? '') ?? DateTime.now(),
            updatedAt: DateTime.tryParse(itemMap['updated_at'] ?? '') ?? DateTime.now(),
            unreadCount: {},
            isPinned: itemMap['is_pinned'] ?? false,
            groupName: itemMap['name'],
            profile_picture: itemMap['profile_picture'],
            unread_count: itemMap['unread_count'],
          ));
        } else if (itemMap['type'] == 'user') {
          // Handle private chat with user - store user name in groupName for display
          chats.add(Chat(
            id: itemMap['id'].toString(),
            type: 'user', // Keep original type for API calls
            participants: [itemMap['id'].toString()],
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
            unreadCount: {},
            isPinned: itemMap['is_pinned'] ?? false,
            groupName: itemMap['name'], // Store user name here for display
            profile_picture: itemMap['profile_picture'], // Store user name here for display
            unread_count: itemMap['unread_count'], // Store user name here for display
          ));
        }
      }
      
      debugPrint('Parsed ${chats.length} chats');
      
      state = state.copyWith(
        chats: chats,
        isLoading: false,
      );
    } catch (e) {
      debugPrint('Error loading chat list: $e');
      state = state.copyWith(
        error: e.toString(),
        isLoading: false,
      );
    }
  }

  void loadUserChats(String userId) {
    state = state.copyWith(isLoading: true);

    FirebaseService.getUserChats(userId).listen(
      (chats) {
        state = state.copyWith(
          chats: chats,
          isLoading: false,
        );
      },
      onError: (error) {
        state = state.copyWith(
          error: error.toString(),
          isLoading: false,
        );
      },
    );
  }

  Future<void> pinChat(String chatId, bool isPinned) async {
    try {
      await FirebaseService.pinChat(chatId, isPinned);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }

  Future<String> createPrivateChat(String otherUserId, String currentUserId) async {
    try {
      final chat = Chat(
        id: '',
        type: 'private',
        participants: [currentUserId, otherUserId],
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
        unreadCount: {},
      );

      return await FirebaseService.createChat(chat);
    } catch (e) {
      state = state.copyWith(error: e.toString());
      rethrow;
    }
  }

  Future<String> createGroupChat({
    required String name,
    required String description,
    required List<String> members,
    required String creatorId,
  }) async {
    try {
      final chat = Chat(
        id: '',
        type: 'group',
        participants: members,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
        unreadCount: {},
        groupName: name,
        groupDescription: description,
        groupRoles: {creatorId: 'admin'},
      );

      return await FirebaseService.createChat(chat);
    } catch (e) {
      state = state.copyWith(error: e.toString());
      rethrow;
    }
  }

  void clearError() {
    state = state.copyWith();
  }
}

final chatProvider = StateNotifierProvider<ChatNotifier, ChatState>((ref) {
  return ChatNotifier();
});
